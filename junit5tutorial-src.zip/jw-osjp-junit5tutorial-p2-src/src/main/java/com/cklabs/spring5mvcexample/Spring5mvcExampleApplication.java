package com.cklabs.spring5mvcexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring5mvcExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring5mvcExampleApplication.class, args);
	}
}
