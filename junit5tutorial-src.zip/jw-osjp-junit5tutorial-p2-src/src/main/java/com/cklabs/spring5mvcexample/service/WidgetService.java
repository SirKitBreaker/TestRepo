package com.cklabs.spring5mvcexample.service;

import java.util.List;
import java.util.Optional;

import com.cklabs.spring5mvcexample.model.Widget;

public interface WidgetService {
	Optional<Widget> findById(Long id);

	List<Widget> findAll();

	Widget save(Widget widget);

	void deleteById(Long id);
}
